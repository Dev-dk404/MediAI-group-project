package com.example.mediapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import data.MyApp;

public class LogInActv extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //MyApp is a static class that is always running in the background to provide access to resources without the need of sending bundles
        MyApp.createData();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in_actv);
        Button button = (Button) findViewById(R.id.btnLogIn);

    }

    public void LogIn(View view) throws InvalidArgumentException {
        if (checkCredentials()) {
            Intent send = null;
            //TODO: uncomment when full authentication is done
            //   if (MyApp.getData().getUser() instanceof Client)
            send = new Intent(LogInActv.this, MenuActv.class);
         /*   if (MyApp.getData().getUser() instanceof DoctorUser)
                send = new Intent(LogInActv.this, MenuActv.class);
            if (send != null)*/
            startActivity(send);
           /* else
                throw new InvalidArgumentException("User is not doctor nor Client");*/
        }

    }

    private boolean checkCredentials() {
        TextView name = (TextView) findViewById(R.id.txtUserId);
        TextView pass = (TextView) findViewById(R.id.txtPassword);

        return MyApp.getData().checkUser(name.getText().toString().toUpperCase(), pass.getText().toString());
    }

    private class InvalidArgumentException extends Exception {
        public InvalidArgumentException(String s) {
        }
    }
}