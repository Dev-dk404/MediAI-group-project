package data;

public abstract class User {
    protected String userID, password, name, surname, phone;

    public User(String userID, String password, String name, String surname, String phone) {
        this.userID = userID;
        this.password = password;
        this.name = name;
        this.surname = surname;
        this.phone = phone;
    }

    public boolean checkCredentials(String id, String pass) {
        return (id.equals(userID) && pass.equals(password));
    }

    public String getName() {
        return name;
    }

    protected void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    protected void setSurname(String surname) {
        this.surname = surname;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
