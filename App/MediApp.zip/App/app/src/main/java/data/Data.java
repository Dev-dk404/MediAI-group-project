package data;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Dictionary;
import java.util.Hashtable;
import java.util.Locale;

public class Data implements Serializable { //implements serializable to be able to be sent from activity to activity
    User user;
    Hashtable<String, User> users;
    ArrayList<Doctor> doctors;
    ArrayList<Client> clients;
    private String[] occupations = new String[]{"orthopaedic surgeon", "pediatrist", "general practitioner", "neurologist", "student"};

    /* This class feeds data to the front end by request*/
    public Data() {

        populateData();
    }

    public void populateData() {
        /*TODO: this method will connect to the remote database and populate the data structures*/

        doctors = new ArrayList<Doctor>();
        clients = new ArrayList<Client>();
        users = new Hashtable<String, User>();
        loadDoctors();
        loadClients();
        loadUsers();


    }

    /*
     * Loads Client objects into the clients data structure, based on data on the database
     * TODO: connect to database
     */
    private void loadClients() {


        //fake scenario, jeremy insures richard and james
        Client jeremy = new Client("U01", "pass1", "Jeremy", "Clarkson", "19690201857", new InsuranceData());
        jeremy.getInsurance().setTitular(jeremy);
        jeremy.getInsurance().setInsuredPeople(new ArrayList<Client>());
        jeremy.getInsurance().addInsured(jeremy);

        Client richard = new Client("U02", "pass1", "Richard", "Hammond", "19690201857", jeremy.getInsurance());
        Client james = new Client("U03", "pass1", "James", "May", "19690201857", jeremy.getInsurance());
        jeremy.getInsurance().addInsured(richard);
        jeremy.getInsurance().addInsured(james);

        clients.add(jeremy);
        clients.add(richard);
        clients.add(james);
    }

    /*
     * Loads all possible users into the users data structure, using their userId as key, from the clients and doctors structures
     */
    private void loadUsers() {
        for (Doctor doc : doctors) {
            users.put(doc.userID.toUpperCase(Locale.ROOT), doc);
        }
        for (Client client : clients) {
            users.put(client.userID.toUpperCase(), client);
        }
    }

    /*
     * Loads Doctor objects into the doctors data structure, based on data on the database
     * TODO: connect to database
     */
    private void loadDoctors() {
        Doctor doc = new Doctor("D01", "pass1", "Armando", "Campa", "0034670501039", occupations[0]);
        doc.available = true;
        doctors.add(doc);


        doc = new Doctor("D02", "pass2", "Victor", "Folgueras", "1234567890", occupations[0]);
        doc.available = false;
        doctors.add(doc);

        doc = new Doctor("D03", "pass3", "Barbara", "Escrig", "0987654321", occupations[4]);
        doc.available = true;
        doctors.add(doc);

        doc = new Doctor("D04", "pass4", "Alvaro", "Saiz", "37423569854", occupations[2]);
        doc.available = true;
        doctors.add(doc);
    }

    /*
    returns the doctor with the assigned index
    @params: int doc, the index for the doctor
     */
    public Doctor getDoctor(int doc) {
        return doctors.get(doc);
    }

    /*
    returns the list of loaded doctors
     */
    public ArrayList<Doctor> getDoctors() {
        return doctors;
    }

    /*
    returns the loaded client
     */
    public User getUser() {
        return user;
    }


    public boolean checkUser(String id, String pass) {
        boolean conditions = false;
        User user = users.get(id);
        if (user != null) {
            if (user.password.equals(pass)) {
                conditions = true;
            }
        }

        if (conditions) {
            this.user = user;
        }
        return conditions;
    }
}
