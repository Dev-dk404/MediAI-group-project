package data;

import java.util.ArrayList;

public class Client extends User {

    String name, surname;
    private InsuranceData insurance;


    protected Client(String userID, String password, String name, String surname, String phone, InsuranceData insurance) {
        super(userID, password, name, surname, phone);
        this.insurance = insurance;
    }

    public InsuranceData getInsurance() {
        return insurance;
    }

    public ArrayList<String> getInsuranceDetails() {
        return insurance.getDetails();
    }
}
