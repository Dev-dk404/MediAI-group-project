package data;

import android.app.Application;

public class MyApp extends Application {
/*
the purpose of this class is to always be running on the background to avoid the need of passing data through activities
 */
    private static Data data;

    public static Data getData() {
        return data;
    }

    @Override
    public void onCreate() {
        super.onCreate();
    }

    public static Data createData(){
        data = new Data();
        data.populateData();
        return data;
    }
}
