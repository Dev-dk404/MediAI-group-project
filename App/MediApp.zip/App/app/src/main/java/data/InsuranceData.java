package data;

import java.util.ArrayList;
import java.util.Date;

class InsuranceData {

    private ArrayList<Client> insuredPeople;
    private Client titular;
    private Date startDate;
    private Date renewedDate;
    private Date endDate;

    protected InsuranceData() {
    }

    protected InsuranceData(Client titular, ArrayList<Client> insured, Date start, Date renew, Date end) {
        this.titular = titular;
        insuredPeople = insured;
        startDate = start;
        renewedDate = renew;
        endDate = end;
    }

    public ArrayList<Client> getInsuredPeople() {
        return insuredPeople;
    }

    public void setInsuredPeople(ArrayList<Client> insuredPeople) {
        this.insuredPeople = insuredPeople;
    }

    public Client getTitular() {
        return titular;
    }

    public void setTitular(Client titular) {
        this.titular = titular;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getRenewedDate() {
        return renewedDate;
    }

    public void setRenewedDate(Date renewedDate) {
        this.renewedDate = renewedDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public void addInsured(Client client) {
        if (!insuredPeople.contains(client)) insuredPeople.add(client);
    }

    public ArrayList<String> getDetails() {
        ArrayList<String> strs = new ArrayList<String>();
        strs.add("Insurance titular: " + titular.getName() + " " + titular.getSurname());
        String str = "";
        for (Client client : insuredPeople) {
            str += client.getName() + " " + client.getSurname() + ",";
        }
        strs.add("Insured people: " + str);

        return strs;
    }
}
