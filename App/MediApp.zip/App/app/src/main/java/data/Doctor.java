package data;

public class Doctor extends User {
    protected Boolean available;
    protected String occupation;

    protected Doctor(String userID, String password, String name, String surname, String phone, String occupation) {
        super(userID, password, name, surname, phone);
        this.occupation = occupation;
    }

    public Boolean getAvailable() {
        return available;
    }

    public void setAvailable(Boolean available) {
        this.available = available;
    }


    public String getOccupation() {
        return occupation;
    }
}
